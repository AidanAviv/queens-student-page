def solution(A, K): #A = array, K = num of rotations
    if K == 0: #If no more rotations, end recursion
        return A
    newArray = [] #Create blank array
    for i in range(-1, len(A)-1): #Start from ending index in A and loop around
        newArray.append(A[i]) #Add index of A to newArray
    return solution(newArray, K - 1) #Recall function, with newArray as A and reducing K
