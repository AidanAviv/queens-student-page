def solution(X, Y, D): #X = start pos, Y = end pos, D = jump dist
    count = 0
    while X < Y: #Continue until X>=Y
        X += D #Add D to X
        count += 1 #Add 1 to count
    return count
