def solution(A): #A = array
    total = 0
    for i in range(len(A)): #Run for length of A
        if A[i] == 0: #If index i in A is 0
            for j in range(i, len(A)): #Run j from i to length of A
                if A[j] == 1: #If index j in A is 1
                    total += 1 #Add 1 to total
    return total
