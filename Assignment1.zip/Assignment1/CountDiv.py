def solution(A, B, K): #A = first num, B = second num, K = divisor
    array = [] #Create empty array
    total = 0
    for i in range(A, B+1): #For loop to create an array with all numbers from A-B inclusive
        array.append(i)
    for i in range (len(array)): #For loop to run over array
        if array[i] % K == 0: #If index is divisible by K
            total += 1 #Add 1 to total
    return total
