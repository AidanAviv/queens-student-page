def solution(A): #A = array
    for i in range (len(A)): #Run for length of A
        total = 0
        for j in range (len(A)): #Run for length of A
            if A[i] == A[j]: #If index i in A = index j in A
                total += 1 #Add to total
            if j == len(A) - 1: #If end of array reached
                if total % 2 != 0: #And total is not divisible by two
                    return A[i] #Return index i in A
    return 0
